const express = require('express');
const{protect, isAdmin} = require('../middleware/authmiddleware');
const{getResearchpapers, submitResearchpaper} = require('../controllers/researchcontroller');
const router = express.Router();
// get all research papers
router.get('/', getResearchpapers);
// submit a research paper
router.post('/', protect, isAdmin, submitResearchpaper);
module.exports = router;