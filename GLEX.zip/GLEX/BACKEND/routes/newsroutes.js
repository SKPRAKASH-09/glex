const express = require('express');
const {protect, isAdmin} = require('../middleware/authmiddleware');
const {getAllNews, createNews} = require('../controllers/newscontroller');
const multer = require('multer');
const upload = multer({dest: 'uploads/'});
const router = express.Router();
// get all news
router.get('/', getAllNews);
// create news
router.post('/', protect, isAdmin, upload.array('images'), createNews);
module.exports = router;