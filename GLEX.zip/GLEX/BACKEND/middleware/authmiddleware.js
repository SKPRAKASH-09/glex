const jwt = require('jsonwebtoken');

const protect = (req, res, next) => { 
    const authHeader = req.header("Authorization");
    if(!authHeader) {
        return res.status(401).json({message: "Access Denied"});

    try {
        const token = authHeader.split(" ")[1]; // EXPECTING FORMAT : "Bearer token"
        const verified = jwt.verify(token, process.env.JWT_SECRET);
        req.user = verified;
        next();
    } catch (error) {
        res.status(401).json({message: "Access Denied"});
    }
};

const isAdmin = (req, res, next) => {
    if(req.user.role !== "admin") return res.status(403).json({message: "admin access required"});
        next();
    }

module.exports = { protect, isAdmin };
