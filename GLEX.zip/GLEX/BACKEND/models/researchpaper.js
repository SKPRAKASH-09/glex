const mongoose = require('mongoose');

const researchPaperSchema = new mongoose.Schema({
    title: { type: String, required: true },
    abstract: { type: String, required: true },
    category: { type: String, required: true },
    author: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    description: { type: String, required: true },
    fileurl: { type: String, required: true },
    approved: { type: Boolean, default: false },
    downloads: { type: Number, default: 0 },
    likes: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
    comments: [{
        text: String,
        postedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
    }], { timestamps: true }
});

module.exports = mongoose.model('ResearchPaper', researchPaperSchema);

