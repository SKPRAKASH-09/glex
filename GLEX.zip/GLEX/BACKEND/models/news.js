const mongoose = require('mongoose');

const newsSchema = new mongoose.Schema({
    title: {
        type: String,
        required: true
    },
    description: {
        type: String,
        required: true
    },
    image: {
        type: String,
        required: true
    },
    category: {
        type: String, enum: ['Announcement', 'sports', 'Academics', 'Clubs', 'PLacement', 'Events', 'Others'],

    },
    author: {
        type: mongoose.Schema.Types.ObjectId, ref: 'User', ref: 'User'
    
    },
    likes:[{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
    comments: [{
        text: String,
        postedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
    }],{timestamps: true}
});

module.exports = mongoose.model('News', newsSchema);