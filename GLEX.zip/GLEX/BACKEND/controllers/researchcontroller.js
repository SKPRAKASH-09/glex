const Researchpaper = require('../models/researchpaper');
// for file uploads, u could integrate multer and cloudinary or store files locally

const getResearchpapers = async (req, res) => {
    try {
        const researchpapers = await Researchpaper.find().populate('author', 'name email');
        res.json(papers);
    } catch (error) {
        res.status(500).json({message: error.message});
    }
};

const submitResearchpaper = async (req, res) => {
    try {
        const {title, abstract, category, description, fileurl} = req.body;
        // fileurl should be the url obtained from uploading the file to cloudinary
        const paper = new Researchpaper({title, abstract, category, description, fileurl, author: req.user._id});
        await paper.save();
        res.status(201).json(paper);
    } catch (error) {
        res.status(500).json({message: error.message});
    }
};
module.exports = {getResearchpapers, submitResearchpaper};