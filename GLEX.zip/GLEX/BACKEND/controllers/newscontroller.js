const News = require('../models/news'); 
// for image upload using cloudinary
const cloudinary = require('cloudinary').v2;
cloudinary.config({
    cloud_name: process.env.CLOUD_NAME,
    api_key: process.env.cloudinary_API_KEY,
    api_secret: process.env.cloudinary_API_SECRET
});

const getAllNews = async (req, res) => {
    try {
        const news = await News.find().populate('author', 'name email');
        res.json(news);
    } catch (error) {
        res.status(500).json({message: error.message});
    }
}

const createNews = async (req, res) => {
    try {
        const {title, content, category} = req.body;
        const {path} = req.file;
        const result = await cloudinary.uploader.upload(path);
        let imageUrls = [];
        // if images are provided (handled by multer), upload to cloudinary
        if(req.files) {
            for(const file of req.files) {
                const {path} = file;
                const result = await cloudinary.uploader.upload(path);
                imageUrls.push(result.secure_url);
            }

        }

        const news = new News({title, content, category, image: result.secure_url, images: imageUrls, author: req.user._id});
        await news.save();
        res.status(201).json(news);
    } catch (error) {
        res.status(500).json({message: error.message});
    }
};

module.exports = {getAllNews, createNews};