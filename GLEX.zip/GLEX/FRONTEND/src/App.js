import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Home from './pages/Home';
import Events from './pages/Events';
import Research from './pages/Research';
import Discussions from './pages/Discussions';

Function App() {
    return (
        <Router>
            <Navbar />
            <div className="container mx-auto">
            <Routes>
                <Route path="/" component={Home} />
                <Route path="/events" component={Events} />
                <Route path="/research" component={Research} />
                <Route path="/discussions" component={Discussions} />
            </Routes>
            </div>
            <Footer />
        </Router>
    );
}

export default App;