import React from 'react';
import { Link } from 'react-router-dom';
Function Navbar() {
    return (
        <nav className="bg-blue-600 text-white p-4">
            <div className="container mx-auto flex justify-between items-center">
                <div>
                    <Link to="/" className="font-bold text-xl">GLEX</Link>
                </div>
                <div className="space-x-4">
                    <Link to="/">Home</Link>
                    <Link to="/events">Events</Link>
                    <Link to="/research">Research</Link>
                    <Link to="/discussions">Discussions</Link>
                </div>
            </div>
        </nav>
    );
}

export default Navbar;
                    