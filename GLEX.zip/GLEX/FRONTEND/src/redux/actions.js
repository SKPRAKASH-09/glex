export const fetchNews = () => async (dispatch) => {
    try {
        const response = await fetch('https://localhost:5000/api/news');
    } catch (error) {
        console.error(error);
    }
};