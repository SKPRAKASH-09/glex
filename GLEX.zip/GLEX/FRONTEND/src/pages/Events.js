import React from 'react';

function Events() {
    return (
        <div>
            <h1 classname="text-3xl font-bold mb-4">Events</h1>
            <p>This is the Events page</p>
        </div>
    );
}

export default Events;