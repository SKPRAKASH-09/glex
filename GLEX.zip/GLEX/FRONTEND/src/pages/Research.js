import React from 'react';
import axios from 'axios';

function Research() {
    const [researchPapers, setResearchPapers] = React.useState([]);

    React.useEffect(() => {
        axios.get('https://localhost:5000/api/research')
            .then(response => setResearchPapers(response.data))
            .catch(error => console.error(error));
    }
    , []);

    return (
        <div>
            <h1 classname="text-3xl font-bold mb-4">Research Papers</h1>
            {Papers.map(paper => (
                <div key={paper._id} className="border p-4 mb-4">
                    <h2 className="text-2xl font-semibold">{paper.title}</h2>
                    <p>{paper.abstract}</p>
                    <a href={paper.fileUrl} target="_blank" rel="noopener noreferrer" className="text-blue-500">Download paper</a>
                </div>
            ))}
        </div>
    );
}   
export default Research;