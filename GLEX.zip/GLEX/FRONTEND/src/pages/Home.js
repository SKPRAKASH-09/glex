import React from 'react';
import axios from 'axios';

function Home() {
    const [news, setNews] = React.useState([]);

    React.useEffect(() => {
        axios.get('https://localhost:5000/api/news')
            .then(response => setNews(response.data))
            .catch(error => console.error(error));
    }, []);

    return (
        <div>
            <h1 classname="text-3xl font-bold mb-4">Latest News</h1>
            {news.map(item => (
                <div key={item.id} className="border p-4 mb-4">
                    <h2 className="text-2xl font-semibold">{item.title}</h2>
                    <p>{item.content}</p>
                </div>
            ))}
        </div>
    );
}

export default Home;