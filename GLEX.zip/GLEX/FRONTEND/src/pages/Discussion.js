import React from 'react';

function Discussion() {
    return (
        <div>
            <h1 classname="text-3xl font-bold mb-4">Discussion</h1>
            <p>This is the Discussion page</p>
        </div>
    );
}

export default Discussion;